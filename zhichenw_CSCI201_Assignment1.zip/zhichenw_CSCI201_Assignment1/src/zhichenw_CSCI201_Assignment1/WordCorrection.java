package zhichenw_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Stack;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;


//********************************* Make a Trie ///////////////////////////////
/////        Trie Node       /////
class TrieNode { // Use the array to indicate the children of a node
    TrieNode[] array;
    boolean isLeaf;
    String mWord;
    
    public TrieNode() { // 26 elements in the array
        this.array = new TrieNode[26];
    }
}

////         Trie           /////    
class Trie {
    private TrieNode root;
    
    // Constructor: set the root
    public Trie() { root = new TrieNode();}
 
    // Insert a word into the trie.
    public void insert(String word) {
        TrieNode p = root;
        for(int i=0; i < word.length(); i++){ // Loop to insert the word
            char c = word.charAt(i);
            if( c == '�' ) c = 'e';	// In case for Spanish accented letters...
            if( c == '�' ) c = 'n';
            int index = c-'a';
            if(p.array[index]==null){// If this letter is vacant, then insert
                TrieNode temp = new TrieNode();	// Set a new node
                p.array[index]=temp;
                p = temp;
            }else{					// If this letter is occupied, then continue
                p=p.array[index];
            }
        }
        p.isLeaf=true;
        p.mWord= word;
    }
 
    // The search helper
    public TrieNode searchHelper(String s){
        TrieNode curr = root;
        for(int i=0; i < s.length(); i++){	// Loop to find through the trie
            char c = s.charAt(i);
            int index = c - 'a';
            if(curr.array[index] != null){
                curr = curr.array[index];
            }
            else{
                return null;
            }
        }
        // If string s is empty
        if(curr==root)
            return null;
 
        return curr;
    }
    // Search if the word is in the trie.
    public boolean search(String word) {
        TrieNode result = searchHelper(word);
  
        if( result != null && result.isLeaf )
        	return true;
        else 
         	return false;
        
    }

    // If there is any word in the trie that starts with the given prefix.
    public boolean startsWith(String prefix) {
        if(searchHelper(prefix) == null) 
            return false;
        else
            return true;
    }
    
    public String[] getWords(String prefix){
    	
    	TrieNode tempNode = searchHelper(prefix);
    	ArrayList<String> tempWords = new ArrayList<>();
    	Stack<TrieNode> mStack = new Stack<TrieNode>();
    	mStack.add(tempNode); 
    	while(!mStack.isEmpty()){
    		tempNode = mStack.pop();
    		if(tempNode.isLeaf) tempWords.add(tempNode.mWord);
    		if(tempWords.size() > 9) break;
    		for(int i=0; i<26; i++){
    			if(tempNode.array[i] != null)
    				mStack.add(tempNode.array[i]);
    		}
    		
    	}
    	
    	String [] words = new String[tempWords.size()];
    	words = tempWords.toArray(words);
    	return words;
    }
}
///////////////////////////////////  Make a Trie (Done) *********************************//


/////*******************     Word Correction and Suggestion   /////////////////////////////
public class WordCorrection {

	
	public static void main(String [] args){

		// To store the file names
		String wlFile = null, kbFile=null, txtFile=null;
		
		// To read the file
		FileReader fr;
		BufferedReader br = null;
		
		// A Trie to store the word list
		Trie myTrie = new Trie();
		
		// 1 array list to store errors of input text file, 1 array list to store keyboard data
		ArrayList<String> errors = new ArrayList<>();
		ArrayList<Character>[] keyboard = new ArrayList[26];
		for(int i=0; i<26; i++) keyboard[i] = new ArrayList<Character>();
		
		//////////////////////////////////Get the file names  /////////////////////////////////
		// Check the command line to find proper files
		for(int i = 0; i < args.length; i++ ){
			String temp = args[i];
			if(temp.endsWith(".wl"))
				wlFile = temp;
			if(temp.endsWith(".kb"))
				kbFile = temp;
			if(temp.endsWith(".txt"))
				txtFile = temp;
			
		}
		
		// If any input files is lack
			if( wlFile == null ){
				System.out.print("Please input wordlist file: ");
				Scanner in = new Scanner(System.in);
				String temp = in.next();
				wlFile = temp;
				in.close();
			}
			if( kbFile == null ){
				System.out.print("Please input keyboard file: ");
				Scanner in = new Scanner(System.in);
				String temp = in.next();
				kbFile = temp;
				in.close();
			}
			if( txtFile == null){
				System.out.print("Please input textfile file: ");
				Scanner in = new Scanner(System.in);
				String temp = in.next();
				txtFile = temp;
				in.close();
			}
		
		//System.out.println( "wlFile: " + wlFile + " kbFile: " + kbFile + " txtFile: " + txtFile  );

		//////////////////////////////////// Read the files ///////////////////////////////////

		// Load the word list file
		try{
			fr = new FileReader( "src/zhichenw_CSCI201_Assignment1/" + wlFile + ".txt" );
			br = new BufferedReader( fr );
			
			while( true ){
				String line = br.readLine();
				if( line == null ) break;
				myTrie.insert(line);
			}
			
			//br.close(); // Put this line in "finally" to close file even there is an exception !!!
		} catch (FileNotFoundException fnfe) {
			System.out.println("FileNotFoundException: " + fnfe.getMessage() );
		} catch (IOException ioe) {
			System.out.println("IOException: " + ioe.getMessage() );
		} 
		finally {
			try {
				if ( br != null) 
		            br.close();
		    } catch (IOException e) {
		    }
		}
		
		//System.out.println(myTrie.search("electroencephalographs"));
		//System.out.println(myTrie.search("aa"));
		
		// Load the text file
		try{
			fr = new FileReader( "src/zhichenw_CSCI201_Assignment1/" + txtFile );
			Scanner sc = new Scanner( fr );
			
			while( sc.hasNext() ){
				String temp = sc.next().toLowerCase();
				String temp1 = "";
				for( int i = 0; i < temp.length(); i++ ){
					if( temp.charAt(i) >= 'a' && temp.charAt(i) <= 'z' ){
						temp1 = temp1 + temp.charAt(i);
					}
				}
				//System.out.println(temp1);
				if( !myTrie.search(temp1) ){
					//System.out.println(temp1);
					errors.add(temp1);
				}
			}
			sc.close();
		} catch( FileNotFoundException fnfe ){
			System.out.println("FileNotFoundException: " + fnfe.getMessage() );
		} 
		
		// Load the keyboard file
		try{
			fr = new FileReader( "src/zhichenw_CSCI201_Assignment1/" + kbFile + ".txt" );
			br = new BufferedReader( fr );

			
			while( true ){
				String line = br.readLine();
				if( line == null ) break;
				char firstLetter = line.charAt(0);
				int index = firstLetter - 'a';
				keyboard[index].add(firstLetter);
				for( int i = 2; i < line.length(); i++ ){
					keyboard[index].add(line.charAt(i));
				}
			}
		} catch( FileNotFoundException fnfe ){
			System.out.println("FileNotFoundException: " + fnfe.getMessage() );
		} catch( IOException ioe ){
			System.out.println("IOException: " + ioe.getMessage() );
		} finally {
			try {
				if ( br != null ) 
		            br.close();
		    } catch ( IOException e ) {
		    }
		}
		/*for(int i = 0; i < keyboard.length; i++){
			System.out.print(i + ": ");
			for(int j=0; j < keyboard[i].size(); j++){
				System.out.print(keyboard[i].get(j));
			}
			System.out.println("");
		}*/
		
		
		// Provide suggestion
		// And pick up at most 10 suggestion
		String[] errWords;
		
		// Write into a file named as a Timestamp
		java.util.Date date= new java.util.Date();
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(date.getTime()));
		FileWriter fw = null; PrintWriter pw = null;
		
		try{
			fw = new FileWriter(timeStamp);
			pw = new PrintWriter(fw);
			
			for(int i = 0; i<errors.size(); i++){
				pw.print( errors.get(i) + ": " );
				errWords = correctWords(errors.get(i), myTrie, keyboard);
				ArrayList<String> buffer = new ArrayList<String>();
				for(int j = 0; j < errWords.length; j++){
					if(j >= 10) break;
					if( buffer.size() >= 10 ) break;
					pw.print(errWords[j] + " ");
					
				}
				pw.println("");
			}
		} catch (IOException ioe){
			System.out.println("IOException: " + ioe.getMessage());
		} finally{
			if(pw != null) pw.close();
			try{
				if(fw != null) fw.close();
			} catch (IOException ioe) {
				System.out.println("IOException closing file: "+ ioe.getMessage());
			}
			
		}
		
		
		
		
		
		
		
		
		
	}
	
	
	// method: recursion to find out all possible correct word
	public static void correctWordsHelper(int times, String input, ArrayList<String> errWords, ArrayList<String> errWordsPrefix, 
							int[] letterIndex, int[] letterIndexMax,
							Trie wlTrie, ArrayList<Character>[] keyboard){
		letterIndex[0]++;
		if(letterIndex[0]>letterIndexMax[0]){
			for(int i = 0; i<letterIndex.length; i++){
				if(letterIndex[letterIndex.length - 1] > letterIndexMax[letterIndex.length - 1]) 
					return;
				if(letterIndex[i] > letterIndexMax[i]){
					letterIndex[i] = 0; 
					letterIndex[i+1]++;
				}
			}
		}
		
		//if(times <= 0) return;
		
			String mask = "";
			for(int i = 0; i<input.length(); i++){
				int temp = input.charAt(i) - 'a';
				mask += keyboard[temp].get(letterIndex[i]);
			}
			if( wlTrie.search(mask) ){
				errWords.add(mask);
			}
			
			/*if( wlTrie.search(mask) && errWordsPrefix.size() < 10){ // It is a prefix
				String [] prefixList = wlTrie.getWords(mask);
				
				for(int i=0; i<prefixList.length; i++){
					System.out.print(prefixList[i] + " ");
					errWordsPrefix.add(prefixList[i]);
				}
					
				System.out.println(prefixList.length);
			}*/
			correctWordsHelper(times - 1, input, errWords, errWordsPrefix, letterIndex, letterIndexMax, wlTrie, keyboard);
		
	}
	
	public static String[] correctWords(String input, Trie wlTrie, ArrayList<Character>[] keyboard) {
		ArrayList<String> errWords = new ArrayList<>();
		ArrayList<String> errWordsPrefix = new ArrayList<>();
		int [] letterIndex = new int[input.length()];
		int [] letterIndexMax = new int[input.length()];
		for(int i=0; i<input.length(); i++){
			letterIndex[i] = 0;
			int tempIndex = input.charAt(i) - 'a';
			letterIndexMax[i] = keyboard[tempIndex].size() - 1;
		}		
		
		correctWordsHelper(10, input, errWords, errWordsPrefix, letterIndex, letterIndexMax, wlTrie, keyboard);
		
		ArrayList<String> errWordAll = new ArrayList<>();
		errWordAll = errWords;
		errWordAll.addAll(errWordsPrefix);  
		String [] results = new String[errWordsPrefix.size() + errWords.size() ];
		results = errWordAll.toArray(results);
		return results;
	}
	
}
